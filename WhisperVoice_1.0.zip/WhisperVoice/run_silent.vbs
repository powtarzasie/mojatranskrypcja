' WhisperVoice — uruchomienie bez okna konsoli
' Dodaj skrót do tego pliku w:
'   C:\Users\<TWOJA_NAZWA>\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup
' ...aby aplikacja startowała automatycznie z systemem.

Dim oShell
Set oShell = CreateObject("WScript.Shell")

' Ścieżka do folderu z WhisperVoice (automatycznie wykrywana)
Dim sDir
sDir = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))

' Uruchom Python bez okna konsoli (0 = ukryte)
oShell.Run "python """ & sDir & "main.py""", 0, False

Set oShell = Nothing
