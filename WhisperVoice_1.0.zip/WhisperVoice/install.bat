@echo off
title WhisperVoice - Instalator

echo.
echo =====================================================
echo   WhisperVoice - Instalator
echo =====================================================
echo.

:: Sprawdz Pythona
python --version >nul 2>&1
if errorlevel 1 (
    echo [BLAD] Python nie jest zainstalowany lub nie ma go w PATH.
    echo        Pobierz Python 3.12 z: python.org/downloads/release/python-3129/
    echo        WAZNE: podczas instalacji zaznacz "Add Python to PATH"
    pause & exit /b 1
)

for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo [OK] Python %PYVER% znaleziony.

echo.
echo [1/3] Aktualizacja pip...
python -m pip install --upgrade pip -q

echo.
echo [2/3] Instalacja pakietow (moze potrwac kilka minut)...
echo       faster-whisper, sounddevice, keyboard, pystray, Pillow, pyperclip, pyautogui
echo.
pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [BLAD] Instalacja nie powiodla sie. Sprawdz komunikaty powyzej.
    pause & exit /b 1
)

echo.
echo [3/3] Sprawdzam CUDA (GPU NVIDIA)...
python -c "import ctranslate2; n=ctranslate2.get_cuda_device_count(); print('[OK] Wykryto', n, 'GPU z CUDA.')" 2>nul || (
    echo [INFO] Brak GPU CUDA lub sterowniki wymagaja aktualizacji.
    echo        Jesli masz karte NVIDIA - zaktualizuj sterowniki z nvidia.com
    echo        Jesli nie masz GPU - zmien w config.py: DEVICE = "cpu"
)

echo.
echo =====================================================
echo   Instalacja zakonczona!
echo.
echo   Nastepny krok: uruchom run.bat
echo   Konfiguracja:  edytuj config.py w Notatniku
echo.
echo   UWAGA: przy pierwszym uruchomieniu zostanie
echo   pobrany model Whisper large-v3 (~3 GB).
echo   Moze to potrwac kilka minut.
echo =====================================================
echo.
pause
