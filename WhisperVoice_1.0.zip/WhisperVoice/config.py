# ╔══════════════════════════════════════════════════════════════════╗
# ║                  WHISPERVOICE — KONFIGURACJA                    ║
# ╚══════════════════════════════════════════════════════════════════╝
#
# Edytuj ten plik, aby dopasować aplikację do swojego sprzętu.
# Po zmianach zrestartuj WhisperVoice.
#
# ── SZYBKI WYBÓR PRESETU ────────────────────────────────────────────
#
#  Laptop  GTX 1660 Ti (6 GB VRAM):
#    MODEL_SIZE   = "large-v3"
#    DEVICE       = "cuda"
#    COMPUTE_TYPE = "int8_float16"   ← mniejsze zużycie VRAM, jakość ≈ float16
#
#  Desktop RTX 3080 / 4080 / 4090 (≥10 GB VRAM):
#    MODEL_SIZE   = "large-v3"
#    DEVICE       = "cuda"
#    COMPUTE_TYPE = "float16"        ← pełna precyzja, najlepsza jakość
#
#  Tylko CPU (bez GPU):
#    MODEL_SIZE   = "medium"
#    DEVICE       = "cpu"
#    COMPUTE_TYPE = "int8"
#
# ────────────────────────────────────────────────────────────────────


# ── MODEL ────────────────────────────────────────────────────────────
# Dostępne rozmiary: tiny | base | small | medium | large-v2 | large-v3
# large-v3 = najlepsza jakość dla polskiego, wymaga GPU z ≥4 GB VRAM
MODEL_SIZE = "large-v3"

# Urządzenie: "cuda" (karta NVIDIA) lub "cpu"
DEVICE = "cuda"

# Typ obliczeń:
#   "float16"      → najlepsza jakość, wymaga ≥8 GB VRAM
#   "int8_float16" → prawie taka sama jakość, ~40% mniej VRAM  ← GTX 1660 Ti
#   "int8"         → tylko CPU
COMPUTE_TYPE = "int8_float16"


# ── JĘZYK ────────────────────────────────────────────────────────────
# "pl"   → polski (wymuszony, szybszy)
# "en"   → angielski
# None   → automatyczne wykrywanie (wolniejsze, ale obsługuje kod-switching)
LANGUAGE = "pl"


# ── HOTKEY ───────────────────────────────────────────────────────────
# Trzymaj hotkey → nagrywanie. Puść → transkrypcja i wklejenie.
# Możliwe formaty: "ctrl+space", "right alt", "f13", "ctrl+shift+r"
HOTKEY = "scroll lock"


# ── AUDIO ────────────────────────────────────────────────────────────
SAMPLE_RATE   = 16000   # Hz — Whisper wymaga 16 kHz, nie zmieniaj
MIN_DURATION  = 0.4     # sekundy — krótsze nagrania są ignorowane
BLOCK_SIZE    = 1024    # próbki — bufor audio (nie zmieniaj)


# ── TRANSKRYPCJA ─────────────────────────────────────────────────────
BEAM_SIZE      = 5      # Wyżej = dokładniej, ale wolniej (5 = dobry balans)
VAD_FILTER     = True   # Usuwa ciszę przed transkrypcją (zalecane)
VAD_MIN_SILENCE_MS = 400  # ms ciszy traktowane jako koniec mowy


# ── WKLEJANIE TEKSTU ─────────────────────────────────────────────────
# "clipboard" → CTRL+V (szybkie, działa wszędzie, zalecane)
# "typing"    → symulacja klawiatury (wolne, może nie działać z polskimi znakami)
INJECT_METHOD  = "clipboard"
INJECT_DELAY   = 0.08   # sekundy przed wklejeniem (nie zmniejszaj poniżej 0.05)


# ── TRAY / WYGLĄD ────────────────────────────────────────────────────
APP_NAME      = "WhisperVoice"
COLOR_IDLE    = (30, 130, 210)   # RGB — kolor ikony w trybie gotowości
COLOR_LOADING = (255, 165, 0)    # RGB — kolor podczas ładowania modelu
COLOR_RECORD  = (220, 50, 50)    # RGB — kolor podczas nagrywania
COLOR_PROCESS = (160, 60, 200)   # RGB — kolor podczas transkrypcji
