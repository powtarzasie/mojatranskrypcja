@echo off
chcp 65001 >nul
title WhisperVoice
cd /d "%~dp0"
echo Uruchamiam WhisperVoice (okno konsoli - tryb debug)...
echo Zamknij to okno lub uzyj ikony w trayu, aby zatrzymac.
echo.
python main.py
pause
