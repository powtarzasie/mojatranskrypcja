"""
WhisperVoice — lokalny voice-to-text dla Windows
Przytrzymaj CTRL+SPACE → mów → puść → tekst pojawia się w aktywnym polu.

Wymaga: pip install faster-whisper sounddevice keyboard pystray pillow pyperclip pyautogui
"""

import threading
import time
import os

import numpy as np

def _add_nvidia_dll_paths():
    """Dodaje ścieżki DLL z pakietów nvidia (pip) do PATH i wyszukiwania Windows."""
    import sys
    added = []
    for base in sys.path:
        nvidia_dir = os.path.join(base, 'nvidia')
        if os.path.isdir(nvidia_dir):
            for pkg in os.listdir(nvidia_dir):
                bin_path = os.path.join(nvidia_dir, pkg, 'bin')
                if os.path.isdir(bin_path) and bin_path not in added:
                    added.append(bin_path)
                    # Dodaj do PATH (główna metoda dla CTranslate2)
                    os.environ['PATH'] = bin_path + os.pathsep + os.environ.get('PATH', '')
                    # Dodaj też przez add_dll_directory (Python 3.8+)
                    try:
                        os.add_dll_directory(bin_path)
                    except Exception:
                        pass

_add_nvidia_dll_paths()
import sounddevice as sd
import keyboard
import pyperclip
import pyautogui
import pystray
from PIL import Image, ImageDraw
from faster_whisper import WhisperModel

import config


# ─────────────────────────────────────────────────────────────────────────────
# Auto-detekcja GPU / CPU
# ─────────────────────────────────────────────────────────────────────────────

def _auto_detect_device() -> None:
    """
    Sprawdza dostepnosc CUDA. Jesli brak karty NVIDIA — automatycznie
    przelacza config na tryb CPU (nadpisuje w pamieci, nie rusza pliku).
    """
    try:
        import ctranslate2
        cuda_count = ctranslate2.get_cuda_device_count()
    except Exception:
        cuda_count = 0

    if cuda_count > 0 and config.DEVICE == "cuda":
        print(f"[WhisperVoice] Wykryto {cuda_count} GPU NVIDIA — tryb CUDA aktywny.")
        print(f"[WhisperVoice] Model: {config.MODEL_SIZE} | compute: {config.COMPUTE_TYPE}")
    else:
        if config.DEVICE == "cuda":
            print("[WhisperVoice] Brak karty NVIDIA lub sterowniki CUDA niedostepne.")
            print("[WhisperVoice] Przelaczam automatycznie na tryb CPU.")
            print("[WhisperVoice] UWAGA: transkrypcja bedzie wolniejsza niz na GPU.")
            config.DEVICE = "cpu"
            config.COMPUTE_TYPE = "int8"
            config.MODEL_SIZE = "medium"
        print(f"[WhisperVoice] Tryb CPU | model: {config.MODEL_SIZE} | compute: {config.COMPUTE_TYPE}")

_auto_detect_device()


# ─────────────────────────────────────────────────────────────────────────────
# Ikona trayu
# ─────────────────────────────────────────────────────────────────────────────

def _draw_icon(color_rgb: tuple, show_dot: bool = False) -> Image.Image:
    """Rysuje okrągłą ikonę z mikrofonem (64×64 RGBA)."""
    size = 64
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # Tło — koło
    r, g, b = color_rgb
    d.ellipse([0, 0, size - 1, size - 1], fill=(r, g, b, 255))

    w = (255, 255, 255, 230)  # biały

    if show_dot:
        # Pulsujący punkt — tryb nagrywania
        d.ellipse([20, 20, 44, 44], fill=w)
    else:
        # Mikrofon: kapsuła + podstawka
        d.rounded_rectangle([24, 8, 40, 34], radius=8, fill=w)
        # Łuk podstawki (dolna półelipsa)
        d.arc([17, 28, 47, 50], start=0, end=180, fill=w, width=3)
        # Pionowy trzon
        d.line([32, 50, 32, 57], fill=w, width=3)
        # Podstawa pozioma
        d.line([25, 57, 39, 57], fill=w, width=3)

    return img


# ─────────────────────────────────────────────────────────────────────────────
# Klasa główna
# ─────────────────────────────────────────────────────────────────────────────

class WhisperVoice:
    def __init__(self):
        self.model: WhisperModel | None = None
        self.icon: pystray.Icon | None = None

        # Stan nagrywania
        self._recording = False
        self._audio_chunks: list[np.ndarray] = []
        self._stream: sd.InputStream | None = None
        self._lock = threading.Lock()

        # Hotkey — guard przed wielokrotnym wyzwoleniem
        self._hotkey_active = False

    # ── Ładowanie modelu ─────────────────────────────────────────────

    def load_model(self) -> None:
        """Ładuje model Whisper w tle; aktualizuje ikonę po zakończeniu."""
        self._set_icon(config.COLOR_LOADING, tip="WhisperVoice — ładowanie modelu…")
        print(f"[WhisperVoice] Ładuję model: {config.MODEL_SIZE} "
              f"({config.DEVICE}, {config.COMPUTE_TYPE})…")
        try:
            self.model = WhisperModel(
                config.MODEL_SIZE,
                device=config.DEVICE,
                compute_type=config.COMPUTE_TYPE,
                num_workers=1,
                cpu_threads=4,
            )
            print("[WhisperVoice] Model gotowy!")
            self._set_icon(config.COLOR_IDLE,
                           tip=f"WhisperVoice — {config.HOTKEY.upper()} aby nagrać")
        except Exception as exc:
            print(f"[WhisperVoice] Błąd ładowania modelu: {exc}")
            print("             Sprawdź DEVICE i COMPUTE_TYPE w config.py")
            self._set_icon((150, 150, 150),
                           tip="WhisperVoice — błąd modelu, sprawdź konsolę")

    # ── Nagrywanie ───────────────────────────────────────────────────

    def _audio_callback(self, indata: np.ndarray, frames: int, t, status) -> None:
        with self._lock:
            if self._recording:
                self._audio_chunks.append(indata.copy())

    def start_recording(self) -> None:
        if self.model is None:
            print("[WhisperVoice] Model jeszcze się ładuje…")
            return

        with self._lock:
            if self._recording:
                return
            self._recording = True
            self._audio_chunks = []

        print("[WhisperVoice] 🎙 Nagrywanie…")
        self._set_icon(config.COLOR_RECORD, dot=True,
                       tip="WhisperVoice — NAGRYWA…")

        try:
            self._stream = sd.InputStream(
                samplerate=config.SAMPLE_RATE,
                channels=1,
                dtype="float32",
                blocksize=config.BLOCK_SIZE,
                callback=self._audio_callback,
            )
            self._stream.start()
        except Exception as exc:
            print(f"[WhisperVoice] Błąd mikrofonu: {exc}")
            with self._lock:
                self._recording = False
            self._set_icon(config.COLOR_IDLE,
                           tip=f"WhisperVoice — {config.HOTKEY.upper()} aby nagrać")

    def stop_recording(self) -> None:
        with self._lock:
            if not self._recording:
                return
            self._recording = False
            chunks = list(self._audio_chunks)
            self._audio_chunks = []

        print("[WhisperVoice] ⏹ Zatrzymano, przetwarzam…")
        self._set_icon(config.COLOR_PROCESS,
                       tip="WhisperVoice — transkrypcja…")

        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None

        # Transkrypcja w osobnym wątku
        threading.Thread(
            target=self._transcribe_and_inject,
            args=(chunks,),
            daemon=True,
        ).start()

    # ── Transkrypcja ─────────────────────────────────────────────────

    def _transcribe_and_inject(self, chunks: list[np.ndarray]) -> None:
        if not chunks:
            self._set_icon(config.COLOR_IDLE,
                           tip=f"WhisperVoice — {config.HOTKEY.upper()} aby nagrać")
            return

        audio = np.concatenate(chunks, axis=0).flatten()
        duration = len(audio) / config.SAMPLE_RATE

        if duration < config.MIN_DURATION:
            print(f"[WhisperVoice] Za krótkie ({duration:.2f}s) — ignoruję.")
            self._set_icon(config.COLOR_IDLE,
                           tip=f"WhisperVoice — {config.HOTKEY.upper()} aby nagrać")
            return

        try:
            segments, info = self.model.transcribe(
                audio,
                language=config.LANGUAGE,
                beam_size=config.BEAM_SIZE,
                vad_filter=config.VAD_FILTER,
                vad_parameters={"min_silence_duration_ms": config.VAD_MIN_SILENCE_MS},
            )

            text = " ".join(seg.text.strip() for seg in segments).strip()

            if text:
                # Usuń wielokrotne spacje
                text = " ".join(text.split())
                print(f"[WhisperVoice] 📝 {text}")
                self._inject_text(text)
            else:
                print("[WhisperVoice] ⚠ Brak mowy / zbyt cicho.")

        except Exception as exc:
            print(f"[WhisperVoice] Błąd transkrypcji: {exc}")

        finally:
            self._set_icon(config.COLOR_IDLE,
                           tip=f"WhisperVoice — {config.HOTKEY.upper()} aby nagrać")

    # ── Wklejanie tekstu ─────────────────────────────────────────────

    def _inject_text(self, text: str) -> None:
        """Wkleja tekst w aktywne pole tekstowe przez schowek (CTRL+V)."""
        time.sleep(config.INJECT_DELAY)

        if config.INJECT_METHOD == "clipboard":
            # Zapisz poprzedni schowek
            try:
                old_clip = pyperclip.paste()
            except Exception:
                old_clip = ""

            # Wklej
            pyperclip.copy(text)
            time.sleep(0.05)
            pyautogui.hotkey("ctrl", "v")
            time.sleep(0.15)

            # Przywróć schowek
            try:
                pyperclip.copy(old_clip)
            except Exception:
                pass

        else:
            # Fallback: symulacja klawiatury (wolne, problematyczne z PL)
            pyautogui.write(text, interval=0.01)

    # ── Hotkey ───────────────────────────────────────────────────────

    def _setup_hotkey(self) -> None:
        """
        Hold-to-talk: przytrzymaj hotkey → nagrywanie, puść → transkrypcja.
        Obsługuje dowolny hotkey z config.py (np. "scroll lock", "ctrl+space").
        """
        _state = {"active": False}

        # Wyodrębnij nazwy klawiszy z hotkey (np. "ctrl+space" → ["ctrl","space"])
        hotkey_keys = [k.strip().lower() for k in config.HOTKEY.split("+")]

        def on_press():
            if _state["active"] or self._recording:
                return
            _state["active"] = True
            self._hotkey_active = True
            threading.Thread(target=self.start_recording, daemon=True).start()

        def on_release(event: keyboard.KeyboardEvent) -> None:
            key = event.name.lower()
            if _state["active"] and key in hotkey_keys:
                _state["active"] = False
                self._hotkey_active = False
                threading.Thread(target=self.stop_recording, daemon=True).start()

        # suppress=True → hotkey NIE trafia do aktywnej aplikacji
        keyboard.add_hotkey(config.HOTKEY, on_press, suppress=True)
        keyboard.on_release(on_release)

    # ── Tray ─────────────────────────────────────────────────────────

    def _set_icon(self, color: tuple, dot: bool = False, tip: str = "") -> None:
        if self.icon:
            self.icon.icon = _draw_icon(color, show_dot=dot)
            if tip:
                self.icon.title = tip

    def _build_menu(self) -> pystray.Menu:
        hotkey_str = config.HOTKEY.upper().replace("+", " + ")
        return pystray.Menu(
            pystray.MenuItem(config.APP_NAME, None, enabled=False),
            pystray.MenuItem(
                f"Model: {config.MODEL_SIZE}  |  {config.DEVICE.upper()}  |  {config.COMPUTE_TYPE}",
                None, enabled=False
            ),
            pystray.MenuItem(f"Hotkey: {hotkey_str}", None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Zakończ", self._quit),
        )

    def _quit(self) -> None:
        print("[WhisperVoice] Zamykanie…")
        if self.icon:
            self.icon.stop()

    # ── Start ────────────────────────────────────────────────────────

    def run(self) -> None:
        print("=" * 60)
        print(f"  {config.APP_NAME} — lokalny voice-to-text (Whisper)")
        print("=" * 60)

        # Ładuj model w tle (pystray wymaga głównego wątku)
        threading.Thread(target=self.load_model, daemon=True).start()

        # Hotkey
        self._setup_hotkey()

        # Tray icon (główny wątek — wymagany przez Windows)
        self.icon = pystray.Icon(
            config.APP_NAME,
            _draw_icon(config.COLOR_LOADING),
            f"{config.APP_NAME} — ładowanie modelu…",
            self._build_menu(),
        )

        print(f"[WhisperVoice] Ikona w trayu aktywna.")
        print(f"[WhisperVoice] Przytrzymaj {config.HOTKEY.upper()} aby nagrywać.")
        self.icon.run()


# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Wyłącz autopozycjonowanie pyautogui (bezpieczeństwo)
    pyautogui.FAILSAFE = False

    app = WhisperVoice()
    try:
        app.run()
    except KeyboardInterrupt:
        print("\n[WhisperVoice] Przerwano przez użytkownika.")
