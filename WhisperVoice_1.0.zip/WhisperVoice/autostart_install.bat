@echo off
title WhisperVoice - Autostart

set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "SCRIPT=%~dp0run_silent.vbs"
set "LINK=%STARTUP%\WhisperVoice.lnk"

echo.
echo  Tworze skrot autostartu dla WhisperVoice...

powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%LINK%'); $s.TargetPath = 'wscript.exe'; $s.Arguments = '\"%SCRIPT%\"'; $s.WorkingDirectory = '%~dp0'; $s.Description = 'WhisperVoice voice-to-text'; $s.Save()"

if exist "%LINK%" (
    echo  [OK] Autostart wlaczony.
    echo       Skrot dodany do: %STARTUP%
    echo.
    echo       Aby WYLACZYC autostart, usun plik:
    echo       %LINK%
) else (
    echo  [BLAD] Nie udalo sie utworzyc skrotu.
    echo         Sprobuj uruchomic jako Administrator (PPM na plik - Uruchom jako administrator).
)

echo.
pause
